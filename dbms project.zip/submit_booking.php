<?php
$host = 'localhost:3307';
$db = 'vehicle_booking';
$user = 'root';
$pass = ''; // Update this if needed

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 1; // Use session-based user_id if available

$sql = "SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Booking History</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #3b82f6, #10b981);
      color: #333;
    }
    header {
      background: #0d6efd;
      color: white;
      padding: 15px;
      text-align: center;
      font-size: 24px;
      font-weight: bold;
    }
    .container {
      background: white;
      margin: 30px auto;
      padding: 30px;
      border-radius: 10px;
      width: 90%;
      max-width: 1000px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      text-align: center;
      border: 1px solid #ddd;
    }
    th {
      background-color: #f0f0f0;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .no-bookings {
      text-align: center;
      font-size: 18px;
      margin-top: 30px;
      color: #555;
    }
    .back-link {
      display: inline-block;
      margin-top: 20px;
      background: #0d6efd;
      color: white;
      padding: 12px 24px;
      border-radius: 5px;
      text-decoration: none;
      font-size: 16px;
    }
    .back-link:hover {
      background: #0b5ed7;
    }
  </style>
</head>
<body>

<header>Booking History</header>

<div class="container">
  <?php if ($result->num_rows > 0): ?>
    <table>
      <tr>
        <th>Vehicle</th>
        <th>Pickup Time</th>
        <th>Drop Time</th>
        <th>From</th>
        <th>To</th>
        <th>Payment</th>
        <th>Peak?</th>
        <th>Prepaid?</th>
        <th>Booked At</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['vehicle_type']) ?></td>
          <td><?= htmlspecialchars($row['pickup_time']) ?></td>
          <td><?= htmlspecialchars($row['drop_time']) ?></td>
          <td><?= htmlspecialchars($row['pickup_location']) ?></td>
          <td><?= htmlspecialchars($row['destination']) ?></td>
          <td><?= htmlspecialchars($row['payment_type']) ?></td>
          <td><?= $row['is_peak'] ? 'Yes' : 'No' ?></td>
          <td><?= $row['prepayment_accepted'] ? 'Yes' : 'No' ?></td>
          <td><?= htmlspecialchars($row['created_at']) ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <div class="no-bookings">No bookings yet.</div>
  <?php endif; ?>
  <a class="back-link" href="mod.php">Back to Home</a>
</div>

</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
